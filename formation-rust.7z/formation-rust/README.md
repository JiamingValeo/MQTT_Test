# Notebooks

Pour lancer le server Jupyter en local:

```
docker-compose up -d
```

Pour l'arrêter un fois terminé:

```
docker-compose down
```

Se connecter à [http://localhost:8080/jupyter](http://localhost:8080/jupyter).

Le mot de passe est: cenotelie

