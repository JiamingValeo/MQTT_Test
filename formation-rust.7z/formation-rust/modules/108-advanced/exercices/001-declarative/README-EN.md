# Exercise 001 -- Declarative macro

Write a declarative macro to compare two `f64` values with a tolerance (EPSILON), given as constant.
