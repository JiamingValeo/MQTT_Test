# Exercice 001 -- Macro déclarative

Ecriture une macro déclarative pour comparer deux valeurs de type f64 avec une certaine valeur de tolérance (EPSILON).