# Exercice 001 -- Compiler avec rustc

## Etape 1
Dans un fichier `main.rs` copier le code Rust suivant :

```rust
fn main() {
    println!("Hello, world!");
}
```

## Etape 2
Compiler :

```sh
rustc main.rs
```

## Etape 3
Exécuter :

```sh
./main
```
