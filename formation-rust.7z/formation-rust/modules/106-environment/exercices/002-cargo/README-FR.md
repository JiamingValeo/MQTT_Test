# Exercice 002 -- Compiler avec cargo

## Etape 1
Créer un nouveau projet Cargo :

```sh
cargo new cargo_hello
```

## Etape 2
Compiler :

```sh
cd cargo_hello
cargo build
```

## Etape 3
Exécuter :

```sh
./target/debug/cargo_hello
```
