In case of problems, within the container:

```bash
echo "nameserver 8.8.8.8" > /etc/resolv.conf
rustup component add rust-src
```
